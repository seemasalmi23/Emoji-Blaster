#define QSL(text) QStringLiteral(text)
